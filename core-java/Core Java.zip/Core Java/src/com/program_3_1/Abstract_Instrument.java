package com.program_3_1;

public abstract class Abstract_Instrument {
	
	public abstract void Play();
	
}